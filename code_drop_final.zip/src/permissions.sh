#/bin/bash
hdfs dfs -setfacl -R -m user:vm1370:rwx rbda/crime 
hdfs dfs -setfacl -R -m user:vaa238:rwx rbda/crime 