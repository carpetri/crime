# Predicting crime using taxi trips data - CODE DROP 3

Authors:

* Carlos Petricioli (cpa253@nyu.edu)
* Valerie Angulo (vaa238@nyu.edu)
* Varsha Muralidharan (vm1370@nyu.edu)

`
code_drop_3
|-- [ 451]  README.md
|-- [3.0K]  analyze_crime.py
|-- [4.7K]  bash_profile_dumbo
|-- [3.4K]  filter_clean_taxi.py
|-- [1.3K]  taxi_zone_centroids.py
`

This folder includes code that runs on spark. This code drop was focused mostly in relating the 3 datasets, crime, weather and taxis and simple iterations in the modeling

## OUTPUT

The result of this process leads to a new iteration in the modeling phase
